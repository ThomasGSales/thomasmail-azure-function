const sgMail = require('@sendgrid/mail');

module.exports = async function (context, req) {
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);

    const { to, subject, text, html } = req.body;

    const msg = {
        to,
        from: 'tgmsales@minha.fag.edu.br', // Substitua pelo e-mail verificado no SendGrid
        subject,
        text,
        html,
    };

    try {
        await sgMail.send(msg);
        context.res = {
            status: 200,
            body: 'Email enviado com sucesso!',
        };
    } catch (error) {
        context.log.error('Erro ao enviar email:', error);
        context.res = {
            status: 500,
            body: 'Erro ao enviar o email.',
        };
    }
};